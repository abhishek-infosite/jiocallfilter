package com.example.jiocallfilter

import android.content.Context
import android.database.Cursor
import android.net.Uri
import android.provider.ContactsContract
import android.telecom.Call
import android.telecom.CallScreeningService
import android.telecom.PhoneAccountHandle

class MyCallScreenService : CallScreeningService() {

    override fun onScreenCall(callDetails: Call.Details) {
        val number = callDetails.handle?.schemeSpecificPart ?: ""
        val simSlot = detectSimSlot(callDetails.accountHandle)

        if (simSlot == 1) {
            if (isInContacts(applicationContext, number)) {
                allowCall(callDetails)
            } else {
                blockCall(callDetails)
            }
        } else {
            allowCall(callDetails)
        }
    }

    private fun allowCall(callDetails: Call.Details) {
        val response = CallResponse.Builder()
            .setDisallowCall(false)
            .setRejectCall(false)
            .setSkipCallLog(false)
            .setSkipNotification(false)
            .build()
        respondToCall(callDetails, response)
    }

    private fun blockCall(callDetails: Call.Details) {
        val response = CallResponse.Builder()
            .setDisallowCall(true)
            .setRejectCall(true)
            .setSkipCallLog(true)
            .setSkipNotification(true)
            .build()
        respondToCall(callDetails, response)
    }

    private fun detectSimSlot(account: PhoneAccountHandle?): Int {
        val id = account?.id?.lowercase() ?: return 2
        return when {
            id.contains("1") || id.contains("sim1") || id.contains("sub1") -> 1
            id.contains("2") || id.contains("sim2") || id.contains("sub2") -> 2
            else -> 2
        }
    }

    private fun isInContacts(context: Context, number: String): Boolean {
        val uri: Uri = Uri.withAppendedPath(
            ContactsContract.PhoneLookup.CONTENT_FILTER_URI,
            Uri.encode(number)
        )
        val projection = arrayOf(ContactsContract.PhoneLookup._ID)
        var cursor: Cursor? = null
        return try {
            cursor = context.contentResolver.query(uri, projection, null, null, null)
            cursor != null && cursor.moveToFirst()
        } finally {
            cursor?.close()
        }
    }
}